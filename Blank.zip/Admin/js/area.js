function SetInput(kode_area,nama,email,status,kode_nas){
	document.getElementById("kode_area").value = kode_area;
	document.getElementById("nama").value = nama;
	document.getElementById("email").value = email;
	document.getElementById("status").value = status;
	document.getElementById("kode_nas").value = kode_nas;
}