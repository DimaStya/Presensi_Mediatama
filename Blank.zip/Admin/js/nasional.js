function SetInput(kode_nasional,nama,email,status){
	document.getElementById("kode_nasional").value = kode_nasional;
	document.getElementById("nama").value = nama;
	document.getElementById("email").value = email;
	document.getElementById("status").value = status;
}