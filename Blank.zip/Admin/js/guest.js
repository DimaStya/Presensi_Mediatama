function SetInput(kode_guest,nama_guest,jabatan,email){
	document.getElementById("kode_guest").value = kode_guest;
	document.getElementById("nama").value = nama_guest;
	document.getElementById("jabatan").value = jabatan;
	document.getElementById("email").value = email;
}