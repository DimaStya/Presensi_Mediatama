function SetInput(kode_perwakilan,nama,email,alamat_perwakilan,status,kode_nas){
	document.getElementById("kode_perwakilan").value = kode_perwakilan;
	document.getElementById("nama").value = nama;
	document.getElementById("email").value = email;
	document.getElementById("alamat_perwakilan").value = alamat_perwakilan;
	document.getElementById("status").value = status;
	document.getElementById("kode_nas").value = kode_nas;
}