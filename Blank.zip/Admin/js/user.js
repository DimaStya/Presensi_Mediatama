function SetInput(nama,email,pass){
	document.getElementById("nama").value = nama;
	document.getElementById("email").value = email;
	document.getElementById("pass").value = pass;
}