function SetInput(kode_sales,nama,email,kode_nas){
	document.getElementById("kode_sales").value = kode_sales;
	document.getElementById("nama").value = nama;
	document.getElementById("email").value = email;
	document.getElementById("kode_nas").value = kode_nas;
}